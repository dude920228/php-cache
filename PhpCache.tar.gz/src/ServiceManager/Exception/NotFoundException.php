<?php

namespace PhpMq\ServiceManager\Exception;

/**
 * Description of NotFoundException
 *
 * @author kdudas
 */
class NotFoundException extends \Exception
{
    //put your code here
}
