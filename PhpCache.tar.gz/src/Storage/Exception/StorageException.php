<?php

namespace PhpCache\Storage\Exception;

/**
 * Description of newPHPClass
 *
 * @author kdudas
 */
class StorageException extends \Exception
{
    //put your code here
}
