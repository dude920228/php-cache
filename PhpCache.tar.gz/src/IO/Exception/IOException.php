<?php

namespace PhpCache\IO\Exception;

/**
 * Description of IOException
 *
 * @author kdudas
 */
class IOException extends \Exception
{
    //put your code here
}
